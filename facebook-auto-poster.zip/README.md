# Facebook Auto Poster 🚀

এই টুল ব্যবহার করে আপনি গুগল ট্রেন্ডস ভিত্তিক SEO-অপ্টিমাইজড কনটেন্ট Facebook-এ অটো পোস্ট করতে পারবেন।

## স্টেপ টু রান লোকালি:
1. `npm install`
2. `npm run dev`

## হোস্টিং Render এ:
- Render এ ফ্রন্টএন্ড (React) ও ব্যাকএন্ড (Express) ডেপ্লয় করুন
- ফ্রন্টএন্ড থেকে `/api/post` রিকুয়েস্ট পাঠাবে

## Blogger Embed:
<iframe src="https://your-app.onrender.com" width="100%" height="600px" frameborder="0"></iframe>