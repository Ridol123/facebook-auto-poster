const express = require('express');
const cors = require('cors');
const app = express();
app.use(cors());
app.use(express.json());

// Placeholder for Facebook + Gemini posting logic
app.post('/api/post', async (req, res) => {
  const { topics, country } = req.body;
  console.log(`Generating ${topics} posts for ${country}...`);

  // Here you would fetch Google Trends, generate content using Gemini, and post to Facebook
  res.json({ message: `${topics} post(s) successfully sent to Facebook.` });
});

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));